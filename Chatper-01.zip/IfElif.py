#condition example
n = int(input('enter sales amt :'))


tax = 0
if n>10000:
    tax = n*.18
elif n>5000:

    
    tax = n*.12
elif n>1000:

    
            tax = n*.10
                
else:
        tax = n*.05

total = n+tax
print('total amt is ',total)




