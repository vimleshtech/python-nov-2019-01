#condition example
a = int(input('enter data :'))
b = int(input('enter data :'))
c = int(input('enter data :'))

#NESTED IF ELSE
if a>b:
    if a>c:
        print('a is greater ')
    else:
        print('c is greater')
else:
    if b>c:
        print('b is greater')
    else:
        print('c is greater ')

#or
if a>b and a>c:
    print('a is greater')
elif b>a and b>c:
    print('b is greater')
else:
    print('c is greater ')





    

          
