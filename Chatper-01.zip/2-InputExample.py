#read data from user 
a =  int(input('enter data :')) #default input type is str 
b = int(input('enter data :'))

c = a+b
print(c)


#format
print('sum of two numbers ',c,end='') #print and don't change line 
print('sum of a and b is  c')
print('sum of ',a,' and ',b,' is  ',c)


print('sum of {} and {} is  {}'.format(a,b,c))
print('sum of {0} and {1} is  {2}'.format(a,b,c))

print('sum of {1} and {0} is  {2}'.format(a,b,c))

#error 
#print('sum of {1} and {0} is  {}'.format(a,b,c))
