#condition example
n = int(input('enter sales amt :'))

t = 0

#python is identation based langauge 
if n>1000:
    t = n*.18


total_amt = n + t
print('total amt is ',total_amt)

#if else

t = 0

#python is identation based langauge 
if n>1000:
    t = n*.18
else:
    t = n*.05
    
total_amt = n + t
print('total amt is ',total_amt)


   

