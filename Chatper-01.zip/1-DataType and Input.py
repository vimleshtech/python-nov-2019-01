#read data from user 
a = input('enter data :') #default input type is str 
b = input('enter data :')

#print data type 
print(type(a)) 
print(type(b))

#type casting/type conversion
a = int(a)
b = int(b)

#add number
c =a+b
print(c)


