#loop example
#while loop
i =1
while i<10:
    print(i)
    i= i+1


print(i)

#print in reverse order
i =10
while i>0:
    print(i)
    i =i-1
    

#for loop
for x in range(10):
    print(x)
    
#in reverse order
for x in range(10,0,-1):
    print(x)


#wap to print sum of all even and odd numbers between two given range
a= int(input('enter data :'))
b= int(input('enter data :'))

se = 0
so = 0
for x in range(a,b+1):
    if x%2 ==0:
        se =se+x
    else:
        so+= x

print('sum of all even ',se)
print('sum of all odd ',so)






        

    




    

